package SpringDataJPAapplication.springDataJPAapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpAapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
